<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Roberttech Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="js/boxOver.js"></script>
</head>
<body>
<div id="main_container">
  <div class="top_bar">
    <div class="top_search">
      <div class="search_text"><a href="http://shanztech.wix.com/tech/">Advanced Search</a></div>
      <input type="text" class="search_input" name="search" />
      <input type="image" src="images/search.gif" class="search_bt"/>
    </div>
    <div class="languages">
      <div class="lang_text">Languages:</div>
      <a href="http://shanztech.wix.com/tech/" class="lang"><img src="images/en.gif" alt="" border="0" /></a> <a href="http://shanztech.wix.com/tech/" class="lang"><img src="images/de.gif" alt="" border="0" /></a> </div>
  </div>
  <div id="header">
    <div id="logo"> <a href="http://shanztech.wix.com/tech/"><img src="images/logo.png" alt="" border="0" width="221" height="112" /></a> </div>
    <div class="oferte_content">
      <div>t<img src="images/headerphoto.gif" width="507" height="57" /><img src="images/online.gif" width="183" height="57" /></div>
      <div class="oferta">
        <div class="oferte_content"><img src="images/welcome.gif" width="595" height="66" /></div>
      </div>
    </div>
    <!-- end of oferte_content-->
  </div>
  <div id="main_content">
    <div id="menu_tab">
      <ul class="menu">
        <li><a href="home.html" class="nav1">HOME</a></li>
        <li class="divider"></li>
        <li><a href="about.html" class="nav2">ABOUT US </a></li>
        <li class="divider"></li>
        <li><a href="special.html" class="nav3">SPECIAL</a></li>
        <li class="divider"></li>
        <li><a href="http://shanztech.wix.com/tech/" class="nav4">BLOG</a></li>
        <li class="divider"></li>
        <li><a href="http://shanztech.wix.com/tech/" class="nav4">SERVICES</a></li>
        <li class="divider"></li>
        <li><a href="shipping.html" class="nav5"> SHIPPING</a></li>
        <li class="divider"></li>
        <li><a href="contact.html" class="nav6">CONTACT US </a></li>
        <li class="divider"></li>
        <li class="currencies">Currencies
          <select>
            <option>RFW</option>
            <option>US Dollar</option>
            <option>Euro</option>
          </select>
        </li>
      </ul>
    </div>
    <!-- end of menu tab -->
    <div class="crumb_navigation"> Navigation: <span class="current">Home</span> </div>
    <div class="left_content">
      <div class="title_box">CATEGORIES</div>
      <ul class="left_menu">
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Desktop</a><a href="http://shanztech.wix.com/tech/">Laptop</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Smartphone</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Frigerator</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Home electronic  </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Storage devices (Flash disk,Sd card) </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Office accessories </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/"> Used Laptop </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Intebe zo munzu </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Computer accessories </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Processors</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Others</a></li>
      </ul>
      <div class="title_box">Best sold </div>
      <div class="border_box">
        <div class="product_title"><a href="details.html">Hp 630</a></div>
        <div class="product_img"><a href="details.html"><img src="images/laptop.png" alt="" border="0" /></a></div>
        <div class="prod_price"> <span class="price">270 000 RFW</span></div>
      </div>
      <div class="title_box">Newsletter</div>
      <div class="border_box">
        <input type="text" name="newsletter" class="newsletter_input" value="your email"/>
        <a href="http://shanztech.wix.com/tech/" class="join">join</a> </div>
      <div class="banner_adds"> <a href="http://shanztech.wix.com/tech/"><img src="images/bann2.jpg" alt="" border="0" /></a> </div>
    </div>
    <!-- end of left content -->
	<div>
	<div>
    <div class="center_content">
      <div>
        <h1 align="center"><font color="#FFFFFF">Welcome to Robert tech</font></h1>
        <h3 align="center"><font color="#FFFF66">Robert tech  is Rwandan company that deals with technology,telecommunication and software development. With this website Robert tech will help you to order your wishes online.</font></h3>
        <h3 align="center"><font color="#FFFFFF">We welcome you</font></h3>
      </div>
      <div class="center_title_bar">Latest products  </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Hp 630 </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (1).png" width="69" height="91" /></a></div>
          <div class="prod_price"><span class="price">220 000 </span> RFW </div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"> <a href="http://shanztech.wix.com/tech/" title="header=[Specials] body=[&nbsp;] fade=[on]"></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.html" class="prod_details">details</a> <a href="details.html" class="prod_buy"><font color="#FFFFFF">Buy</font></a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Iphone 5 </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (2).jpg" width="100" height="89" /></a></div>
          <div class="prod_price"><span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"> <a href="http://shanztech.wix.com/tech/" title="header=[Add to cart] body=[&nbsp;] fade=[on]"></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.html" class="prod_details">details</a></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.html" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Windows phone </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (4).jpg" width="117" height="104" /></a></div>
          <div class="prod_price"><span class="price">200 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a> <a href="details.html" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Motorola 156 MX-VL</a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (6).jpg" width="88" height="89" /></a></div>
          <div class="prod_price"> <span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a><a href="details.html" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Iphone Apple</a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (8).jpg" width="96" height="92" /></a></div>
          <div class="prod_price"><span class="price">7000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a><a href="details.html" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Samsung Webcam</a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (1).gif" width="70" height="88" /></a></div>
          <div class="prod_price"> <span class="price">27 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a><a href="details.html" class="prod_buy">Buy </a> </div>
      </div>
      <div class="center_title_bar">Recommended Products</div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Sumsung Galaxy S6 </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone-153650_960_720.png" width="98" height="100" /></a></div>
          <div class="prod_price"> <span class="price">470 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a> <a href="details.html" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Acer 230 </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (7).jpg" width="86" height="103" /></a></div>
          <div class="prod_price"><span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a> <a href="details.html" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.html">Acer new 430 </a></div>
          <div class="product_img"><a href="details.html"><img src="images/smartphone (2).gif" width="57" height="92" /></a></div>
          <div class="prod_price"> <span class="price">250 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.html" class="prod_details">details</a><a href="details.html" class="prod_buy">Buy </a> </div>
      </div>
    </div>
    <!-- end of center content -->
    <div class="right_content">
      <div class="shopping_cart">
        <div class="cart_title">Shopping cart  </div>
        <div class="cart_details"> 3 items <br />
          <span class="border_cart"></span> Total: <span class="price">850 000</span> </div>
        <div class="cart_icon"><a href="http://shanztech.wix.com/tech/" title="header=[Checkout] body=[&nbsp;] fade=[on]"><img src="images/shoppingcart.png" alt="" width="67" height="49" border="0" /></a></div>
      </div>
      <div class="title_box">What�s new</div>
      <div class="border_box">
        <div class="product_title"><a href="details.html">Motorola 156 MX-VL</a></div>
        <div class="product_img"><a href="details.html"><img src="images/p2.gif" alt="" border="0" /></a></div>
        <div class="prod_price"> <span class="price">300 000RFW</span></div>
      </div>
      <div class="title_box">Manufacturers</div>
      <ul class="left_menu">
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Sony</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Samsung</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Dall</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">LG</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Lenovo</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Motorola</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Phillips</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Beko</a></li>
      </ul>
      <div class="banner_adds">
        <p><a href="http://shanztech.wix.com/tech/"><img src="images/funny_faces.jpg" width="225" height="229" /></a> </p>
        <h2><font color="#FFFF00">Site Admin </font></h2>
      </div>
    </div>
    <!-- end of right content -->
  </div>
  <!-- end of main content -->
  <div class="footer">
    <div class="left_footer"> <img src="images/footer_logo.png" alt="" width="164" height="48"/>
	  <div class="leftfooter">
	    <h5>Your Account</h5>
        <p><a href="#">YOUR ACCOUNT</a><br>
            <a href="#">PERSONAL INFORMATION</a><br>
            <a href="#">ADDRESSES</a><br>
            <a href="#">DISCOUNT</a><br>
            <a href="#">ORDER HISTORY</a></p>
        <p><br>
                        </p>
	  </div>
	</div>
    <div class="center_footer">
	<a href="http://csscreme.com"><img src="images/csscreme.jpg" alt="csscreme" width="86" height="21" border="0" /></a><br />
      <img src="images/payment.gif" alt="" />
	  <div class="centerfooter">
	  <h5>Join our social media pages </h5>
      <a href="#"><img width="60" height="60" src="images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="#"><img width="60" height="60" src="images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="#"><img width="60" height="60" src="images/youtube.png" title="youtube" alt="youtube"/></a>
	  </div> 
	  <h3><font color="#FFCC99">Robert electronic. All Rights Reserved 2017</font><br />
      </h3>
    </div>
	
    <div class="right_footer"> 
      <h5><a href="http://shanztech.wix.com/tech/">home</a> <a href="http://shanztech.wix.com/tech/">about</a> <a href="http://shanztech.wix.com/tech/">sitemap</a> <a href="http://shanztech.wix.com/tech/">rss</a> <a href="contact.html">contact us</a>      </h5>
    
      <div class="rightfooter">
        <h5>Our Offer</h5>
		
		 <p><a href="#">NEW PRODUCTS</a><br>
            <a href="#">TOP SELLER</a><br>
            <a href="#">SPECIAL</a><br>
            <a href="#">TOP MANUFACTURES</a><br>
            <a href="#">SUPPLIERS</a></p>
        <p><br>
                        </p>
        
      </div>
    </div>
	</div>
</div>
<!-- end of main_container -->
<div align=center>This website developed by <a href='http://shanztech.wix.com/tech/'>Robert tech ltd </a></div>
</body>
</html>
