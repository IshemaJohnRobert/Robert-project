<?php
session_start();
mysql_connect("localhost","root","");
mysql_select_db("database");
$robert=@$_POST['username'];
$roberto=@$_POST['password'];

$sql="SELECT * FROM login WHERE username='$robert' and password='$roberto'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1)
{
$_SESSION['login']=true;
echo('WELCOME !!!');
include("admin.php");
}
else
{
include("home.php");
}
?>
                                                                                                                                                                                                                                                                                                                                                                                                  