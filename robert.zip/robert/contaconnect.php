<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
$con=mysql_connect("localhost","root","") or die("failed to load").mysql_error();
$select=mysql_select_db("database",$con) or die("fAILED!!!").mysql_error();

$Names=$_POST['Names'];
$Company=$_POST['Company'];
$Email=$_POST['Email'];
$Telephone=$_POST['Telephone'];
$Message=$_POST['Message'];

mysql_query("INSERT INTO Message (Names,Company,Email,Telephone,Message) VALUES('$Names','$Company','$Email','$Telephone','$Message')")or die(mysql_error());
echo "Your message  has been sent successfully!!!";
?>
</body>
</html>
