<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>connect.php</title>
</head>

 <form action "connect.php" method="post">
       <label>Id</label><input type="text" name="Id" id='Id'><br/><br/><br/><br/>
	   <label>Title</label><input type="text" name="Title" id='Title'><br/><br/><br/><br/>
       <label>First name</label><input type="text" name="First name" id='First name'><br/><br/><br/><br/>
           <label>Last name</label><input type="text" name="Last name" id='Last name'><br/><br/><br/><br/>
		   <label>Address</label><input type="text" name="Address" id='Address'><br/><br/><br/><br/>
       <label>Email</label><input type="text" name="Email" id='Email'><br/><br/><br/><br/>
           <label>Password</label><input type="text" name="Password" id='Password'><br/><br/><br/><br/>
		   <label>Birthdate</label><input type="text" name="Date of Birth" id='Date of Birth'><br/><br/><br/><br/>
        
          <input type="submit" value="submit"></p>
</form>

<body>
</body>
</html>
