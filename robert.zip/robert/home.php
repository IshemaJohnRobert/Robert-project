<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Roberttech Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="js/boxOver.js"></script>
</head>
<body>
<div id="main_container">
<div id="menu_fixed">
 
 <ul class="menu">
        <li><a href="home.php" class="nav11">HOME</a></li>
        <li class="divider"></li>
        <li><a href="about.php" class="nav22">ABOUT US </a></li>
        <li class="divider"></li>
        <li><a href="special.php" class="nav33">SPECIAL</a></li>
        <li class="divider"></li>
        <li><a href="login.php" class="nav44">REGISTER</a></li>
        <li class="divider"></li>
        <li><a href="services.php" class="nav44">SERVICES</a></li>
        <li class="divider"></li>
        <li><a href="shipping.php" class="nav55"> SHIPPING</a></li>
        <li class="divider"></li>
        <li><a href="contact.php" class="nav66">CONTACT US </a></li>
        <li class="divider"></li>
        
      </ul>     
    	
</div>
  <div class="top_bar">
    <div class="top_search">
      <div class="search_text"><a href="http://shanztech.wix.com/tech/">Advanced Search</a></div>
      <input type="text" class="search_input" name="search" />
      <input type="image" src="images/search.gif" class="search_bt"/>
    </div>
    <div class="languages">
      <div class="lang_text">Languages:</div>
      <a href="http://shanztech.wix.com/tech/" class="lang"><img src="images/en.gif" alt="" border="0" /></a> <a href="http://shanztech.wix.com/tech/" class="lang"><img src="images/de.gif" alt="" border="0" /></a> </div>
  </div>
<div id="header">
    <div id="logo"> <a href="http://shanztech.wix.com/tech/"><img src="images/logo.png" alt="" border="0" width="221" height="112" /></a> </div>
    <div class="oferte_content">
      <div>t<img src="images/headerphoto.gif" width="507" height="57" /><img src="images/online.gif" width="183" height="57" /></div>
      <div class="oferta">
        <div class="oferte_content"><img src="images/welcome.jpg" width="610" height="60" /></div>
      </div>
    </div>
  <!-- end of oferte_content-->
    <img src="images/camera.gif" width="127" height="130" /></div>
  <div id="main_content">
    <div id="menu_tab">
      <ul class="menu">
        <li><a href="home.php" class="nav1">HOME</a></li>
        <li class="divider"></li>
        <li><a href="about.php" class="nav2">ABOUT US </a></li>
        <li class="divider"></li>
        <li><a href="special.php" class="nav3">SPECIAL</a></li>
        <li class="divider"></li>
        <li><a href="login.php" class="nav4">REGISTER</a></li>
        <li class="divider"></li>
        <li><a href="services.php" class="nav4">SERVICES</a></li>
        <li class="divider"></li>
        <li><a href="help.php" class="nav5"> HELP</a></li>
        <li class="divider"></li>
        <li><a href="contact.php" class="nav6">CONTACT US </a></li>
        <li class="divider"></li>
		<li><a href="login.php" class="nav6">ADMIN </a></li>
        <li class="divider"></li>
        <li class="currencies">Currencies
          <select>
            <option>RFW</option>
            <option>US Dollar</option>
            <option>Euro</option>
          </select>
        </li>
      </ul>
    	
</div>
    <!-- end of menu tab -->
    <div class="crumb_navigation"> Navigation: <span class="current">Home</span> </div>
    <div class="left_content">
      <div class="title_box">CATEGORIES</div>
      <ul class="left_menu">
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Desktop</a><a href="http://shanztech.wix.com/tech/">Laptop</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Smartphone</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Frigerator</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Home electronic  </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Storage devices (Flash disk,Sd card) </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Office accessories </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/"> Used Laptop </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Intebe zo munzu </a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Computer accessories </a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Processors</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Others</a></li>
      </ul>
      <div class="title_box">Best sold </div>
      <div class="border_box">
        <div class="product_title"><a href="details.php">Hp 630</a></div>
        <div class="product_img"><a href="details.php"><img src="images/laptop.png" alt="" border="0" /></a></div>
        <div class="prod_price"> <span class="price">270 000 RFW</span></div>
      </div>
      <div class="title_box">Newsletter</div>
      <div class="border_box">
        <input type="text" name="newsletter" class="newsletter_input" value="your email"/>
        <a href="http://shanztech.wix.com/tech/" class="join">join</a> </div>
      <div class="banner_adds"> <a href="http://shanztech.wix.com/tech/"><img src="images/bann2.jpg" alt="" border="0" /></a> </div>
    </div>
    <!-- end of left content -->
	<div>
	<div>
    <div class="center_content">
      <div>
        <h3 align="center"><font color="#FFFFFF">Welcome to Robert tech</font>,<font color="#00FFFF">Below are some of new products on the market </font></h3>
        <div id="slide1"><img src="images/pc.gif" width="220" height="149" /></div>
		<div id="slide1"><img src="images/camera.gif" width="216" height="153" /></div>
		<div id="slide2"><img src="images/other.gif" width="213" height="154" /></div>
        <h3 align="center">&nbsp;</h3>
        <h2 align="center"><font color="#FFFFFF"></font></h2>
      </div>
      <div class="center_title_bar">Latest products  </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Hp 630 </a></div>
          <div class="product_img"><a href="details.php"><img src="images/laptop.gif" alt="" width="94" height="89" border="0" /></a></div>
          <div class="prod_price"><span class="price">220 000 </span> RFW </div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"> <a href="http://shanztech.wix.com/tech/" title="header=[Specials] body=[&nbsp;] fade=[on]"></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.php" class="prod_details">details</a> <a href="details.php" class="prod_buy"><font color="#FFFFFF">Buy</font></a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Iphone 5 </a></div>
          <div class="product_img"><a href="details.php"><img src="images/smartphone (1).png" width="52" height="83" /></a></div>
          <div class="prod_price"><span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"> <a href="http://shanztech.wix.com/tech/" title="header=[Add to cart] body=[&nbsp;] fade=[on]"></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.php" class="prod_details">details</a></a> <a href="http://shanztech.wix.com/tech/" title="header=[Gifts] body=[&nbsp;] fade=[on]"></a> <a href="details.php" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Samsung Webcam</a></div>
          <div class="product_img"><a href="details.php"><img src="images/p5.gif" alt="" border="0" /></a></div>
          <div class="prod_price"><span class="price">200 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a> <a href="details.php" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Motorola 156 MX</a></div>
          <div class="product_img"><a href="details.php"><img src="images/smartphone (1).gif" width="70" height="88" /></a></div>
          <div class="prod_price"> <span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a><a href="details.php" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Sandisk  </a></div>
          <div class="product_img"><a href="details.php"><img src="images/IMG-20170209-WA0020.jpg" width="80" height="85" /></a></div>
          <div class="prod_price"><span class="price">7000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a><a href="details.php" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Samsung Webcam</a></div>
          <div class="product_img"><a href="details.php"><img src="images/IMG-20170219-WA0007.jpg" width="72" height="83" /></a></div>
          <div class="prod_price"> <span class="price">27 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a><a href="details.php" class="prod_buy">Buy </a> </div>
      </div>
      <div class="center_title_bar">Recommended Products</div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Sumsung Galaxy S6 </a></div>
          <div class="product_img"><a href="details.php"><img src="images/smartphone (8).jpg" width="85" height="86" /></a></div>
          <div class="prod_price"> <span class="price">470 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a> <a href="details.php" class="prod_buy">Buy </a></div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Acer 230 </a></div>
          <div class="product_img"><a href="details.php">\<img src="images/big_pic.jpg" width="97" height="86" /></a></div>
          <div class="prod_price"><span class="price">270 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a> <a href="details.php" class="prod_buy">Buy </a> </div>
      </div>
      <div class="prod_box">
        <div class="top_prod_box"></div>
        <div class="center_prod_box">
          <div class="product_title"><a href="details.php">Acer new 430 </a></div>
          <div class="product_img"><a href="details.php"><img src="images/IMG-20170213-WA0014.jpg" width="100" height="84" /></a></div>
          <div class="prod_price"> <span class="price">250 000 </span>RFW</div>
        </div>
        <div class="bottom_prod_box"></div>
        <div class="prod_details_tab"><a href="details.php" class="prod_details">details</a><a href="details.php" class="prod_buy">Buy </a> </div>
      </div>
    </div>
    <!-- end of center content -->
	
    <div class="right_content">
	<ul class="nav pull-right">
			<li class="dropdown"> </li>
			<li class="dropdown"><h2 align="center"> <font color="#00FF99">Login</font><font color="#FFFF00"><a data-toggle="dropdown" class="dropdown-toggle" href="#"></a></font></h2>
		    <a data-toggle="dropdown" class="dropdown-toggle" href="#"><b class="caret"></b></a>			    </li>
			<li class="dropdown">
			  <div class="loginback">
			    <form class="form-horizontal loginFrm">
			      <div class="control-group">
			        <input type="text" class="span2" id="inputEmail" placeholder="Email">
		          </div>
			      <div class="control-group">
			        <input type="password" class="span2" id="inputPassword" placeholder="Password">
		          </div>
			      <div class="control-group">
			        <label class="checkbox">
			        <input type="checkbox"> Remember me			        </label>
			        <button type="submit" class="shopBtn btn-block">Sign in</button>
			      </div>
			    </form>
		      </div>
		    </li>
	</ul>
      <div class="shopping_cart">
        <div class="cart_title">Shopping cart  </div>
        <div class="cart_details"> 3 items <br />
          <span class="border_cart"></span> Total: <span class="price">850 000</span> </div>
        <div class="cart_icon"><a href="http://shanztech.wix.com/tech/" title="header=[Checkout] body=[&nbsp;] fade=[on]"><img src="images/shoppingcart.png" alt="" width="67" height="49" border="0" /></a></div>
      </div>
      <div class="title_box">What�s new</div>
      <div class="border_box">
        <div class="product_title"><a href="details.php">Motorola 156 MX-VL</a></div>
        <div class="product_img"><a href="details.php"><img src="images/p2.gif" alt="" border="0" /></a></div>
        <div class="prod_price"> <span class="price">300 000RFW</span></div>
      </div>
      <div class="title_box">Manufacturers</div>
      <ul class="left_menu">
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Sony</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Samsung</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Dall</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">LG</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Lenovo</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Motorola</a></li>
        <li class="odd"><a href="http://shanztech.wix.com/tech/">Phillips</a></li>
        <li class="even"><a href="http://shanztech.wix.com/tech/">Beko</a></li>
      </ul>
      <div class="banner_adds">
        <div class="border_box">
          <div class="product_title"><a href="details.php"><font color="#FFFF00"><strong>This is help info</strong><h3></h3></font></a></div>
          <div class="product_img"><a href="details.php">
		  
		  <video width="270" height="265" controls>
  <source src="tuto.mp4" type="video/mp4">
Your browser does not support the video tag.
</video><br />

<a href="tuto.mp4"download>download</a>
</a><br />
<br />
<audio width="270" height="260" controls
  <source src="How To Buy.mp3" type="audio/mp3">
  <source src="How To Buy.mp3" type="audio/ogg">
</audio
></div>
          
		  
        </div>
        <p><a href="http://shanztech.wix.com/tech/"></a> </p>
        <h3><font color="#FFFF00">Watch the video to know how </font></h3>
      </div>
    </div>
    <!-- end of right content -->
  </div>
  <!-- end of main content -->
  <div class="footer">
    <div class="left_footer"> <img src="images/footer_logo.png" alt="" width="164" height="48"/>
	  <div class="leftfooter">
	    <h5><font color="#FFFF00">Your Account</font></h5>
        <h3><strong><font color="#0000FF">YOUR ACCOUNT<em><br />
        </em><a href="#"><em>PERSONAL INFORMATION</em></a></font></strong><br>
            <a href="#">ADDRESSES</a><br>
            <a href="#">DISCOUNT</a><br>
        <a href="#">ORDER HISTORY</a></h3>
        <p><br>
        </p>
	  </div>
	</div>
    <div class="center_footer">
	<a href="http://csscreme.com"><img src="images/csscreme.jpg" alt="csscreme" width="86" height="21" border="0" /></a><br />
      <img src="images/payment.gif" alt="" width="148" height="24" />
	  <div class="centerfooter">
	  <h5><font color="#FFFF00">Join our social media pages </font></h5>
      <a href="https://www.facebook.com/ishemaa"><img width="60" height="60" src="images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="https://twitter.com/IshemaRoshan"><img width="60" height="60" src="images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="https://www.youtube.com/channel/UC_JmZrUPc0EWBUhqw9ot2zg"><img width="60" height="60" src="images/youtube.png" title="youtube" alt="youtube"/></a>
	  </div> 
	  <h3><font color="#FFCC99">Robert electronic. All Rights Reserved 2017</font><br />
      </h3>
    </div>
	
    <div class="right_footer"> <img src="images/footer_logo.png" alt="" width="164" height="48"/>
	  <div class="rightfooter">
	    <h5><font color="#FFFF00">NEWPRODUCT</font></h5>
        <h3><strong><font color="#0000FF">TOP SELLERT<em><br />
        </em><a href="#"><em>TOP MANUFACTURES</em></a></font></strong><br>
            <a href="#">SHIPING</a><br>
            <a href="#">DISCOUNT</a><br>
        <a href="#">ORDER HISTORY</a></h3>
        <p><br>
        </p>
	  </div>
	</div>
</div>
<!-- end of main_container -->
<div align=center>
  <h3><font color="#00FFFF">This website developed by</font><a href='http://shanztech.wix.com/tech/'><font color="#FF0000">Robert tech ltd </font></a></h3>
</div>
</body>
</html>
